
public interface BoardDelegate {
    public void didMove(Board board);
}